<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>php</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
</body>
</html>
Amir 
<h1>Amir</h1>
<div class="test">
<?php
    echo "this is my frist php program ";
    $num1=40;
    $num2=80;
    $result=$num1+$num2;
    echo '<br>' .result;
    ?>
    <div class="side">
        <h4>IIST</h4>

    </div>
</div>
   