<footer class="container-fluid footer1">
    <div class="container">
    <div class="row">
      <div class="col-sm-6 footer_left">
      <?php  dynamic_sidebar('footerleft');  ?>
      </div>
      <div class="col-sm-6 footer_right">
      <?php  dynamic_sidebar('footerright');  ?> 
      </div>
    </div>
    <div class="row">o</div>
    </div>
  </footer>
  <!-- footer part end -->

 


<?php wp_footer(); ?>
</body>
</html>